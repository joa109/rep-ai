REP AI 3.0 — Advanced offline web prototype

Publish by replacing index.html in your existing GitHub rep-ai repository, then commit the change. GitHub Pages should redeploy automatically.

Features: existing workout/goals/history plus performance lab, estimated PRs, training metrics, rule-based session outline generator, recovery self-check-in, export/import backup.

This is not a live AI service or medical device. Data stays in the browser localStorage. Export backups before clearing browser data or switching devices.
